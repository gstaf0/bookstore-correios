Grupo 01:

Felipe Augusto
Renato Foot
Guilherme Staffa
Rafael Lopes
Vitor Feltrin
