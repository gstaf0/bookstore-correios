package br.unicamp.bookstore;

public class BookstoreView {

	
	
}
